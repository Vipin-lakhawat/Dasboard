const express = require('express');
const router = express.Router();
const UserController = require('../Controller/userController.js');


router.post('/',UserController.userLogin)
router.post('/Userlist',UserController.create)
router.post("/Adduser",UserController.create)
router.get('/Userlist1',UserController.find)
// router.put('/update_user/:id',UserController.update)
router.get('/Userlist/:id',UserController.recorddelete)
router.post('/update_user/:id',UserController.update_user)


router.get('/',UserController.Login)
router.get('/Dashboard',UserController.dashboard)
router.get('/Userlist',UserController.userlist)
router.get('/Adduser',UserController.Adduser)
router.get('/update_user/:id',UserController.update_user1)

module.exports=router