const mongoose = require('mongoose');

//Defining Schema
const userSchema = new mongoose.Schema({
    name:{type:String,required:true, trim:true},
    email:{type:String,required:true, unique:true,trim:true},
    gender:{type:String,required:true},
    status:{type:String,required:true}
    
})

const users = mongoose.model("users", userSchema)

module.exports=users 