const mongoose = require('mongoose');

//Defining Schema
const userSchema = new mongoose.Schema({
    email:{type:String,required:true, trim:true},
    password:{type:String,required:true, trim:true}
})

const admins = mongoose.model("admins", userSchema)

module.exports=admins