const Admins = require('../Models/manager.js');
const Users = require('../Models/Userdata.js');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const axios = require('axios');
class UserController {

    static userLogin = async (req, res) => {
        try {
            let { email, password } = req.body;

            let admin = Admins.findOne({ email: email })

            if (!admin) {
                res.send("Invaid email and passwords")
            }

            if (admin.password === password) {
                res.render("Dashboard");
            } else {
                res.send("Invaid email and passwords")
            }
        } catch (error) {
            console.log(error)
            res.send(error)
        }

    }

    //create and save new user 

    static create = (req, res) => {
        if (!req.body) {
            res.status(400).send({ message: "Content can not be empty!" });
            return;
        }
        //new user
        const user = new Users({
            name: req.body.name,
            email: req.body.email,
            gender: req.body.gender,
            status: req.body.status
        })
        //save user in the database
        user
            .save(user)
            .then(data => {
                // res.send(data)
                res.redirect('/Userlist')
            })
            .catch(err => {
                res.status(500).send({
                    message: err.message || "some error occurred while creating a create operation"
                });
            });
    }

    //retrieve and return all users/retrive and return a single user

    static find = (req, res) => {
        if (req.query.id) {
            const id = req.query.id;

            Users.findById(id)
                .then(data => {
                    if (!data) {
                        res.status(404).send({ message: "Not found user with id" + id })
                    } else {
                        res.send(data)
                    }
                })
                .catch(err => {
                    res.send(500).send({ message: "Error retrieving user with id" + id })
                })

        } else {
            Users.find()
                .then(user => {
                    res.send(user)
                })
                .catch(err => {
                    res.status(500).send({ message: err.message || "Error Occurred while retriving user information" })
                })
        }
    }

    // Update a new identified user by user id

    // static update = (req, res) => {
    //     if (!req.body) {
    //         return res
    //             .status(400)
    //             .send({ message: "Data to update can not be empty" })
    //     }
    //     const id = req.params.id;
    //     Users = Users.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    //         .then(data => {
    //             if (!data) {
    //                 res.status(404).send({ message: `Cannot Update user with ${id}.Maybe user not found!` })
    //             } else {
    //                 res.redirect("Userlist",{Users});
    //             }
    //         })
    //         .catch(err => {
    //             res.status(500).send({ message: "Error Update user information" })
    //         })
    // }

    // Delete a new identified user by user id

    static recorddelete = (req, res) => {
        const id = req.params.id;
        Users.findByIdAndDelete(id)
            .then(data => {
                if (!data) {
                    console.log(data);
                    res.status(404).send({ message: `Cannot Delete with id ${id}. Maybe id is wrong` })
                } else {
                    res.redirect("/Userlist");
                }
            })
            
            .catch(err => {
                res.status(500).send({
                    message: "Could not delete User with id=" + id
                });
            });
    }

    static Login = async (req, res) => {
        res.render("Login")
    }

    static update_user1 = async (req, res) => {
        const emp = await Users.findOne({ _id: req.params.id })
        // console.log(emp)
        res.render("update_user",{emp})
    }


    static dashboard = async (req, res) => {
        res.render("Dashboard")
    }

    static userlist = async (req, res) => {
        axios.get('http://localhost:3900/Userlist1')
            .then(function (response) {
                res.render('Userlist', { Users: response.data });
            })
            .catch(err => {
                res.send(err);
            })
    }

    static Adduser = async (req, res) => {
        res.render("Adduser")
    }


    static update_user = async (req, res) => {
       
        console.log("kjgkjggjg",req.body)
        try {
            
            const emp = await Users.findOne({ _id: req.params.id });
            console.log(emp)
        if (!emp) {
            res.send({ staus: "error" });
        } else {
                emp.name = req.body.name
                emp.email = req.body.email
                emp.gender = req.body.gender
                emp.status = req.body.status
                await emp.save();

            res.redirect("/Userlist");
        }
        } catch (error) {
            console.log(error)
        }
        
    }
}

module.exports = UserController

