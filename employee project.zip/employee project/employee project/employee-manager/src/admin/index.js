const dotenv = require("dotenv");
dotenv.config();
const express = require('express');
const bodyParser = require('body-parser');
const connectdb = require('./config/connectdb.js')
const userRoutes = require('./routes/userRoutes.js');
const ejs = require("ejs"); 
const app = express();
const path = require('path')

app.use(bodyParser.urlencoded({ extended:false}));


//connect database
const port = process.env.PORT
const DATABASE_URL = process.env.DATABASE_URL
connectdb(DATABASE_URL)


//connect static files
app.use(express.static(path.join(__dirname,"assets")));
app.use('/css',express.static(path.join(__dirname,"assets/css")));
app.use('/js',express.static(path.join(__dirname,"assets/js")));

//connect ejs files 
const views = path.join(__dirname, 'views')
app.set("views", views)
app.use(express.json())
app.set("view engine", "ejs")


app.use("/", userRoutes)

app.listen(port, () =>{
    console.log(`Server Listening at http://localhost:${port}`)
})